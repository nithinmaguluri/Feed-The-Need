package com.example.OneMeal.util;

public class Constants
{
    public static final String USER_DB="User_Type";
    public static final String FOOD_DB="Food";
    public static final String FOOD_REQUESTS_DB="Food_Request";
    public static final String AGENT_DB = "Volunteer";
}
