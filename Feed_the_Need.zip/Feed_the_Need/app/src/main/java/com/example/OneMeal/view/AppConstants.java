package com.example.OneMeal.view;

public class AppConstants {

    public static final int LOCATION_REQUEST = 1000;
    public static final int GPS_REQUEST = 1001;
}
